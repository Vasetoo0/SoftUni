package OOP.WorkingWithAbstraction.TrafficLigths;

public enum TrafficLight {
    RED,
    GREEN,
    YELLOW;

}
